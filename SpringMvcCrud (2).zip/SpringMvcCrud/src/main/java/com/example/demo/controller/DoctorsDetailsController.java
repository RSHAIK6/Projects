package com.example.demo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.bean.DoctorsDetails;
import com.example.demo.service.DoctorsDetailsService;


@Controller
public class DoctorsDetailsController {

	@Autowired
	private DoctorsDetailsService doctorsdetailService;
	
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET) 
	public String showWelcomePage(ModelMap model) { 
		model.put("name",getLoggedinDoctName()); 
		return "welcome"; 
	}

	private String getLoggedinDoctName() {
		Object principal = SecurityContextHolder.getContext() .getAuthentication().getPrincipal();

		if (principal instanceof DoctorsDetails) { 
			return ((DoctorsDetails) principal).getDoctName(); 
		}
		return principal.toString(); 
	}
	 
	
	// 1 . to display list of doctors
	
	@GetMapping("/index")
	public String viewHomePage(Model model){
		
		/*
		 * model.addAttribute("ListDoctorsDetails",doctorsdetailService.
		 * getAllDoctorsDetails()); return "index";
		 */
		
		return findPaginated(1,"doctName","asc",model);
		 
	}
	
	// 2. to add new doctor detail
	
	
	
	  @GetMapping("/showNewDoctorDetailsForm") 
	  public String showNewDoctorDetailsForm(Model model) {
      DoctorsDetails doctorsdetails = new DoctorsDetails(); 
      model.addAttribute("doctorsdetails", doctorsdetails);
	  return "new_doctorsDetails" ;
	 
	  }
	 
	 
	//3. save new DoctorsDetails
     @PostMapping("/saveDoctorsDetails")
	 public String saveDoctorsDetails(@ModelAttribute("doctorsdetails") DoctorsDetails doctorsdetails ) {
	   doctorsdetailService.saveDoctorsDetails(doctorsdetails);
	   
		return "redirect:/index";
		}
	 
		
		  @GetMapping("/showFormForEdit/{id}")
		  public String showFormForEdit(@PathVariable(value="id") int id,Model model) {
			  
			  DoctorsDetails doctorsdetails = doctorsdetailService.getDoctorsDetailsById(id);
			  
			  model.addAttribute("doctorsdetails", doctorsdetails);
			return "edit_doctorsDetails";
		 }
		
		  @GetMapping("/deleteDoctorDetails/{id}")
		  public String deleteDoctorDetails(@PathVariable(value="id") int id) {
			  // call delete DoctorDetails method
			  this.doctorsdetailService.deleteDoctorDetailsById(id);
			
			  return "redirect:/index";
		  }

		  
		  //page / sorting
		  
		  @GetMapping("/page/{pageNo}")
		  public String findPaginated(@PathVariable (value="pageNo") int pageNo, 
				  @RequestParam("sortField") String sortField,
				  @RequestParam("sortDir") String sortDir,
				  Model model) {
        	 int pageSize=4;
        	 
        	 Page<DoctorsDetails> page=doctorsdetailService.findPaginated(pageNo, pageSize,sortField,sortDir);
        	 List<DoctorsDetails> ListDoctorsDetails=page.getContent();
        	 
        	 model.addAttribute("currentPage",pageNo);
        	 model.addAttribute("totalPages",page.getTotalPages());
        	 model.addAttribute("totalItems",page.getTotalElements());
        	 
        	
        	 model.addAttribute("sortField",sortField);
        	 model.addAttribute("sortDir",sortDir);
        	 model.addAttribute("reverseSortDir",sortDir.equals("asc") ? "desc" : "asc");
        	 
        	 model.addAttribute("ListDoctorsDetails",ListDoctorsDetails);
        	 
			return "index";
			  
		  } 
		  
}


