package com.example.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.bean.DoctorsDetails;


public interface DoctorsDetailsRepository extends JpaRepository<DoctorsDetails, Integer> {


}
