package com.example.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.example.demo.bean.DoctorsDetails;

public interface DoctorsDetailsService {

	List<DoctorsDetails> getAllDoctorsDetails();

	void saveDoctorsDetails(DoctorsDetails doctorsdetails);
	
	
	DoctorsDetails getDoctorsDetailsById(int id);
	
	void deleteDoctorDetailsById(int id);
	
	Page<DoctorsDetails> findPaginated(int pageNo, int pageSize,String sortField ,String sortDirection);

	
}
