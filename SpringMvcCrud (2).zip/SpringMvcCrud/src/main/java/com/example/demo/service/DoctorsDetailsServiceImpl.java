package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.bean.DoctorsDetails;
import com.example.demo.repository.DoctorsDetailsRepository;

@Service
public class DoctorsDetailsServiceImpl implements DoctorsDetailsService {

	@Autowired
	private DoctorsDetailsRepository doctorsdetailsRepository;
	
	
	@Override
	public List<DoctorsDetails> getAllDoctorsDetails() {

		return doctorsdetailsRepository.findAll();
	}

	
	@Override
	public void saveDoctorsDetails(DoctorsDetails doctorsdetails) {
		this.doctorsdetailsRepository.save(doctorsdetails);
		
		
	}


	
	@Override
	public DoctorsDetails getDoctorsDetailsById(int id) {
	Optional<DoctorsDetails> optional=doctorsdetailsRepository.findById(id);
		DoctorsDetails doctorsdetails=null;
		if(optional.isPresent()) {
			doctorsdetails=optional.get();
		}else {
			throw new RuntimeException("Doctor not found for id:: "+id);
		}
		return doctorsdetails;
		
	}

	@Override
	public void deleteDoctorDetailsById(int id) {
		this.doctorsdetailsRepository.deleteById(id);
		
	}


	
	 @Override 
	 public Page<DoctorsDetails> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
	  Sort sort=sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending() :
		  Sort.by(sortField).descending();
		
	 Pageable pageable=PageRequest.of(pageNo - 1, pageSize,sort);
	 return this.doctorsdetailsRepository.findAll(pageable); 
	 }





}

