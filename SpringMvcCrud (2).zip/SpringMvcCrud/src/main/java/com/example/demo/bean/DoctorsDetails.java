package com.example.demo.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="DOCTORSDETAILS")
public class DoctorsDetails {

	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy= GenerationType.IDENTITY)
	 */
	

	@Id
	@Column(name = "doctorsDetails_Id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "doctorsDetails_Sequence")
	@SequenceGenerator(name = "doctorsDetails_Sequence", sequenceName = "ID_SEQ")
	public int id;
	
	@Column(name="DOCT_NAME")
	public String doctName;
	
	@Column(name="DEPARTMENT")
	public String department;
	
	@Column(name="EXPERIENCE")
	public int experience;
	
	@Column(name="MOBILE_NO")
	public long mobileNo;
	
	@Column(name="E_MAIL")
	public String eMail;
	
	@Column(name="ADDRESS")
	public String address;

	public DoctorsDetails(int id, String doctName, String department, int experience, long mobileNo, String eMail,
			String address) {
		super();
		this.id = id;
		this.doctName = doctName;
		this.department = department;
		this.experience = experience;
		this.mobileNo = mobileNo;
		this.eMail = eMail;
		this.address = address;
	}

	public DoctorsDetails() {
		
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDoctName() {
		return doctName;
	}

	public void setDoctName(String doctName) {
		this.doctName = doctName;
	}


	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	
	
	
}
